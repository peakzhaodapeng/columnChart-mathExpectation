﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;//使用chart需要增加一个头文件

namespace probability
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Queue<int>grade_queue=new Queue<int>();
        public const int section_num=6;
        public double mathexpect;
        private void button1_Click(object sender, EventArgs e)
        {
            
            int max_value,min_value;//队列里面的最大值和最小值
            float interval;//每一个区间的长度，可能是小数
            float[] section = new float[section_num+1];//区间端点值
            int[] section_NUM=new int[section_num];//在每个区间的个数
            //int[]grade_array=new int[11]{63,75,85,86,88,92,99,75,77,87,77};//成绩数组
            int[] grade_array = new int[15] { 63, 75, 85, 86, 88, 92, 99, 75, 77, 87, 77,90,90,90,85 };//成绩数组
           // int[] grade_array = new int[4] { 10,10,20,30 };
            for (int num = 0; num < grade_array.Length; num++)//把数组里面的数放在队列里面
            {
                grade_queue.Enqueue(grade_array[num]);
            }
            max_value = grade_queue.Max();//求最大值
            min_value = grade_queue.Min();//求最小值
            interval = (max_value - min_value) / section_num;//每一个区间的长度，可能是小数
            for (int section_cnt = 0; section_cnt < section_num+1; section_cnt++)//求每一个区间的端点值
            {
                section[section_cnt] = min_value + interval * section_cnt;
            }
            for (int section_NUM_CNT = 0; section_NUM_CNT < section_num; section_NUM_CNT++)//求每一个区间里面有多少个数
            {
                if (section_NUM_CNT < section_num - 1)
                {
                    for (int i = 0; i < grade_array.Length; i++)
                    {

                        if ((grade_array[i] - min_value) / interval >= section_NUM_CNT && (grade_array[i] - min_value) / interval < section_NUM_CNT + 1)
                        {
                            section_NUM[section_NUM_CNT] += 1;

                        }
                    }
                }
                else
                {
                    for (int i = 0; i < grade_array.Length; i++)
                    {

                        if (((grade_array[i] - min_value) / interval >= section_NUM_CNT && (grade_array[i] - min_value) / interval < section_NUM_CNT + 1) || grade_array[i]==max_value)
                        {
                            section_NUM[section_NUM_CNT] += 1;

                        }
                    }
                }
               
            
            }
            //求每一个区间的概率
                //显示到column chart上
            Series series1 = chart1.Series[0];
            // 画样条曲线（Spline）
            series1.ChartType = SeriesChartType.Column;

            // 图示上的文字            
            series1.IsVisibleInLegend = true;   //图示上的文字 
            
         
            // 设置显示范围
            ChartArea chartArea1 = chart1.ChartAreas[0];
            chartArea1.AxisX.LabelStyle.Interval = 0;
            chartArea1.AxisX.LabelStyle.IntervalOffset = interval;
            

            chartArea1.AxisX.Minimum = min_value-interval*2;//根据最大值最小值自动调整chart显示范围
            chartArea1.AxisX.Maximum =max_value+interval*2;//这个值支持双精度浮点数，肯定支持负数和小数了
            chartArea1.AxisX.IsMarginVisible = false;
            chartArea1.AxisY.Minimum = 0;
            chartArea1.AxisY.Maximum = 1d;
            for (int i = 0; i < section_NUM.Length; i++)
            {
                chart1.Series[0].Points.AddXY(section[i]+interval/2,section_NUM[i]/(double)grade_array.Length);//区间端点值放在横坐标上，区间内点的个数放在纵坐标上
                chart1.Series[0].IsValueShownAsLabel = true;//值作为标签显示在图表中
                //chart1.Series[0]["PointWidth"] = (interval/2).ToString();
                chart1.Series[0]["PointWidth"] = "1";//这里等于1才合适
               // chart1.Series[0].ShadowOffset = (int)interval*2; //这个是阴影
                mathexpect += (section[i] + interval / 2) * (section_NUM[i] / (double)grade_array.Length);
                
            }
            textBox1.Text = mathexpect.ToString();







            /*假设已经知道每个区间的概率*/
            //float[] grade_array = new float[3] { 0.2f,0.5f,0.3f };//成绩数组
            //Series series1 = chart1.Series[0];
            //// 画样条曲线（Spline）
            //series1.ChartType = SeriesChartType.Column;
           
            //// 图示上的文字            
            //series1.IsVisibleInLegend = true;   //隐藏图示上的文字          
            //// 设置显示范围
            //ChartArea chartArea1 = chart1.ChartAreas[0];

            //chartArea1.AxisX.Minimum = 1;
            //chartArea1.AxisX.Maximum = 5;//这个值支持双精度浮点数，肯定支持负数和小数了

            //chartArea1.AxisY.Minimum =0;
            //chartArea1.AxisY.Maximum = 1d;
            //for (int i = 0; i < grade_array.Length; i++)
            //{
            //    chart1.Series[0].Points.AddY(grade_array[i]);
            //}

        }
    }
}
